import { GoogleGenAI, ThinkingLevel } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function chatStream(messages: { role: "user" | "assistant"; content: string }[], systemInstruction?: string) {
  const chat = ai.chats.create({
    model: "gemini-3-flash-preview",
    config: {
      systemInstruction: systemInstruction || "You are Smart Open AI, a sophisticated AI assistant. You are helpful, precise, and professional. Your theme is grey and white. You can generate images upon request using your built-in image synthesis engine. If a user asks for an image in English or Dutch (e.g., 'maak een plaatje'), confirm that you are generating it.",
      thinkingConfig: { thinkingLevel: ThinkingLevel.LOW }
    }
  });

  const lastMessage = messages[messages.length - 1].content;
  
  return await chat.sendMessageStream({
    message: lastMessage,
  });
}

export async function generateImageFromPrompt(prompt: string) {
  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [{ text: prompt }]
    },
    config: {
      imageConfig: {
        aspectRatio: "1:1"
      }
    }
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:${part.inlineData.mimeType};base64,${part.inlineData.data}`;
    }
  }
  return null;
}
