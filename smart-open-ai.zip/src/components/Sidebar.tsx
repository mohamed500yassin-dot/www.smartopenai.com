import { useState, useEffect } from "react";
import { db, auth, logout } from "../lib/firebase";
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, where, deleteDoc, doc } from "firebase/firestore";
import { Plus, MessageSquare, User, LogOut, Settings, Sparkles, Sun, Moon, Trash2 } from "lucide-react";
import { cn } from "../lib/utils";
import { motion } from "motion/react";

interface Chat {
  id: string;
  title: string;
  createdAt: any;
}

interface SidebarProps {
  currentChatId: string | null;
  onChatSelect: (id: string | null) => void;
  onOpenProfile: () => void;
  isDarkMode: boolean;
  toggleTheme: () => void;
}

export function Sidebar({ currentChatId, onChatSelect, onOpenProfile, isDarkMode, toggleTheme }: SidebarProps) {
  const [chats, setChats] = useState<Chat[]>([]);
  const user = auth.currentUser;

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, "users", user.uid, "chats"),
      orderBy("createdAt", "desc")
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const chatList = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      })) as Chat[];
      setChats(chatList);
    });

    return () => unsubscribe();
  }, [user]);

  const createNewChat = () => {
    onChatSelect(null);
  };

  const deleteChat = async (e: React.MouseEvent, chatId: string) => {
    e.stopPropagation();
    if (!user) return;
    
    try {
      await deleteDoc(doc(db, "users", user.uid, "chats", chatId));
      if (currentChatId === chatId) {
        onChatSelect(null);
      }
    } catch (error) {
      console.error("Error deleting chat:", error);
    }
  };

  return (
    <aside className="w-72 h-full iphone-blur border-r border-zinc-200 dark:border-zinc-800 flex flex-col p-6 font-sans transition-colors duration-300">
      <div className="flex items-center gap-3 mb-10">
        <div className="w-8 h-8 bg-black dark:bg-white flex items-center justify-center rounded-[0.75rem] shrink-0 shadow-md">
          <span className="text-white dark:text-black font-serif text-xl italic">S</span>
        </div>
        <h2 className="text-[10px] font-black uppercase tracking-[0.2em] text-zinc-900 dark:text-white truncate">Smart OpenAI</h2>
      </div>

      <div className="mb-8">
        <button
          onClick={createNewChat}
          className="w-full flex items-center justify-between border border-zinc-200 dark:border-zinc-800 px-6 py-5 rounded-[2rem] hover:bg-zinc-50 dark:hover:bg-zinc-800 transition-all group shadow-sm hover:shadow-md"
        >
          <span className="text-[10px] uppercase font-bold tracking-wider text-zinc-600 dark:text-zinc-400 group-hover:text-black dark:group-hover:text-white">New Conversation</span>
          <Plus className="w-4 h-4 text-zinc-300 dark:text-zinc-700 group-hover:text-black dark:group-hover:text-white" />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar">
        <p className="text-[9px] uppercase tracking-[0.2em] text-zinc-400 dark:text-zinc-600 mb-6 font-bold">History</p>
        <div className="space-y-4">
          {chats.map((chat) => (
            <div key={chat.id} className="relative group">
              <button
                onClick={() => onChatSelect(chat.id)}
                className={cn(
                  "w-full text-left transition-all flex items-start gap-4 pr-10",
                  currentChatId === chat.id 
                    ? "text-black dark:text-white" 
                    : "text-zinc-500 dark:text-zinc-400 hover:text-black dark:hover:text-white"
                )}
              >
                <div className={cn(
                  "w-1 h-5 shrink-0 transition-all rounded-full mt-0.5",
                  currentChatId === chat.id ? "bg-black dark:bg-white" : "bg-zinc-200 dark:bg-zinc-800 opacity-0 group-hover:opacity-100"
                )} />
                <span className={cn(
                  "text-sm line-clamp-1 leading-snug",
                  currentChatId === chat.id ? "font-bold" : "font-normal"
                )}>
                  {chat.title || "Untitled Conversation"}
                </span>
              </button>
              <button
                onClick={(e) => deleteChat(e, chat.id)}
                className="absolute right-0 top-1/2 -translate-y-1/2 p-2 opacity-0 group-hover:opacity-100 text-zinc-300 hover:text-red-500 dark:text-zinc-700 dark:hover:text-red-400 transition-all rounded-lg"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
          {chats.length === 0 && (
            <p className="text-xs text-zinc-400 dark:text-zinc-600 italic font-serif px-5">No recent logic sets...</p>
          )}
        </div>
      </div>

      <div className="mt-auto pt-6 border-t border-zinc-100 dark:border-zinc-800 flex flex-col gap-6">
        <div className="flex items-center justify-between">
            <button
              onClick={onOpenProfile}
              className="flex items-center gap-3 group text-left"
            >
              <div className="w-10 h-10 bg-zinc-200 dark:bg-zinc-800 rounded-full flex items-center justify-center overflow-hidden border border-zinc-300 dark:border-zinc-700 transition-transform group-hover:scale-95 shadow-sm">
                <img 
                  src={user?.photoURL || `https://ui-avatars.com/api/?name=${user?.displayName || 'U'}&background=fff&color=000`} 
                  alt="Avatar" 
                  className="w-full h-full opacity-60 dark:opacity-40" 
                />
              </div>
              <div className="hidden sm:block">
                <p className="text-xs font-bold text-zinc-800 dark:text-zinc-200">{user?.displayName?.split(' ')[0]}</p>
                <p className="text-[9px] text-zinc-400 dark:text-zinc-500 uppercase tracking-widest font-medium">Terminal</p>
              </div>
            </button>

            <button 
                onClick={toggleTheme}
                className="p-3 bg-zinc-50 dark:bg-zinc-800 rounded-xl border border-zinc-200 dark:border-zinc-700 hover:border-zinc-400 transition-colors shadow-sm"
            >
                {isDarkMode ? <Sun className="w-4 h-4 text-zinc-200" /> : <Moon className="w-4 h-4 text-zinc-600" />}
            </button>
        </div>
        
        <button
          onClick={() => logout()}
          className="text-[10px] uppercase tracking-widest font-bold text-zinc-300 dark:text-zinc-700 hover:text-red-500 transition-colors flex items-center justify-center gap-2 py-3 border border-zinc-100 dark:border-zinc-800 rounded-[1.5rem]"
        >
          <LogOut className="w-3 h-3" />
          Terminate Session
        </button>
      </div>
    </aside>
  );
}
