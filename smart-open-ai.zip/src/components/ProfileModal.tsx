import { useState, useEffect } from "react";
import { db, auth } from "../lib/firebase";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { X, User, Settings, Shield, Zap, Sparkles } from "lucide-react";
import { motion } from "motion/react";

interface ProfileModalProps {
  onClose: () => void;
}

export function ProfileModal({ onClose }: ProfileModalProps) {
  const user = auth.currentUser;
  const [preferences, setPreferences] = useState({
    displayName: user?.displayName || "",
    aiVersion: "Smart Pro v2",
    theme: "Light (Grey & White)"
  });
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (!user) return;
    const fetchPrefs = async () => {
      const docRef = doc(db, "users", user.uid, "preferences", "settings");
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setPreferences(prev => ({ ...prev, ...docSnap.data() }));
      }
    };
    fetchPrefs();
  }, [user]);

  const handleSave = async () => {
    if (!user) return;
    setIsSaving(true);
    try {
      await setDoc(doc(db, "users", user.uid, "preferences", "settings"), preferences);
      onClose();
    } catch (error) {
      console.error("Save error:", error);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-zinc-900/10 dark:bg-black/40 backdrop-blur-sm z-50 flex items-center justify-center p-4 transition-colors"
    >
      <motion.div
        initial={{ scale: 0.98, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.98, opacity: 0 }}
        className="bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 shadow-2xl w-full max-w-xl overflow-hidden font-sans rounded-[2rem] transition-all"
      >
        <div className="p-8 border-b border-zinc-100 dark:border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-black dark:bg-white flex items-center justify-center rounded-xl">
              <span className="text-white dark:text-black font-serif text-xl italic">S</span>
            </div>
            <div>
              <h2 className="text-xs font-black uppercase tracking-[0.2em] text-zinc-900 dark:text-white">User Configuration</h2>
              <p className="text-[10px] text-zinc-400 dark:text-zinc-600 uppercase tracking-widest font-medium">Preferences & Terminal settings</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-zinc-50 dark:hover:bg-zinc-800 rounded-full transition-colors">
            <X className="w-5 h-5 text-zinc-400" />
          </button>
        </div>

        <div className="p-8 space-y-10">
          <div className="flex items-center gap-6">
            <div className="w-20 h-20 bg-zinc-100 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-full flex items-center justify-center overflow-hidden">
               <img src={user?.photoURL || ""} className="w-full h-full opacity-80" alt="Avatar" />
            </div>
            <div>
              <h3 className="font-serif text-2xl italic text-zinc-800 dark:text-zinc-200">{user?.displayName}</h3>
              <p className="text-[10px] uppercase font-bold tracking-widest text-zinc-400 dark:text-zinc-600">{user?.email}</p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="space-y-2">
              <label className="text-[9px] uppercase tracking-[0.2em] font-black text-zinc-400 dark:text-zinc-600 ml-1">Identity</label>
              <input 
                type="text" 
                value={preferences.displayName}
                onChange={(e) => setPreferences({ ...preferences, displayName: e.target.value })}
                className="editorial-input !py-4 !text-sm dark:bg-zinc-800 dark:border-zinc-700 dark:text-white rounded-2xl"
              />
            </div>

            <div className="grid grid-cols-2 gap-6">
               <div className="space-y-2">
                  <label className="text-[9px] uppercase tracking-[0.2em] font-black text-zinc-400 dark:text-zinc-600 ml-1">Logic Engine</label>
                  <div className="bg-zinc-50 dark:bg-zinc-800 border border-zinc-100 dark:border-zinc-700 py-4 px-6 text-xs font-bold text-zinc-800 dark:text-zinc-300 uppercase tracking-widest rounded-2xl">
                     {preferences.aiVersion}
                  </div>
               </div>
               <div className="space-y-2">
                  <label className="text-[9px] uppercase tracking-[0.2em] font-black text-zinc-400 dark:text-zinc-600 ml-1">Interface Theme</label>
                  <div className="bg-zinc-50 dark:bg-zinc-800 border border-zinc-100 dark:border-zinc-700 py-4 px-6 text-xs italic font-serif text-zinc-500 dark:text-zinc-400 rounded-2xl">
                     {preferences.theme}
                  </div>
               </div>
            </div>
          </div>

          <div className="border-l-2 border-zinc-900 dark:border-white pl-6 space-y-2">
             <h4 className="text-[10px] uppercase font-black tracking-widest text-zinc-900 dark:text-white">Security Protocol</h4>
             <p className="text-xs text-zinc-500 dark:text-zinc-400 leading-relaxed italic font-serif transition-colors">
                Your conversations are distilled through proprietary encryption layers. 
                Smart Open AI ensures total data sovereignty.
             </p>
          </div>
        </div>

        <div className="p-8 bg-zinc-50 dark:bg-zinc-900/50 border-t border-zinc-100 dark:border-zinc-800 flex justify-end gap-6 items-center">
          <button 
            onClick={onClose}
            className="text-[10px] uppercase font-bold tracking-widest text-zinc-400 hover:text-black dark:hover:text-white transition-colors"
          >
            Cancel
          </button>
          <button 
            onClick={handleSave}
            disabled={isSaving}
            className="bg-black dark:bg-white text-white dark:text-black px-10 py-4 text-[10px] uppercase font-bold tracking-widest hover:bg-zinc-800 dark:hover:bg-zinc-200 transition-all shadow-lg rounded-2xl"
          >
            {isSaving ? "Synchronizing..." : "Apply Changes"}
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
}
