import { motion } from "motion/react";
import { Sparkles } from "lucide-react";

export function SplashScreen() {
  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ 
        opacity: 0,
        scale: 1.1,
        transition: { duration: 0.8, ease: [0.16, 1, 0.3, 1] }
      }}
      className="fixed inset-0 z-[100] bg-white dark:bg-zinc-950 flex flex-col items-center justify-center overflow-hidden transition-colors duration-300"
    >
      <div className="flex-1 flex flex-col items-center justify-center gap-12">
        <motion.div
          initial={{ scale: 0.7, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ 
            duration: 1.2, 
            ease: [0.16, 1, 0.3, 1]
          }}
          className="flex flex-col items-center gap-8"
        >
          {/* Logo Frame - iPhone Squircle Style */}
          <div className="relative flex items-center justify-center">
             <motion.div 
               animate={{ 
                 boxShadow: ["0 0 0 0px rgba(0,0,0,0)", "0 0 0 30px rgba(0,0,0,0.03)", "0 0 0 0px rgba(0,0,0,0)"]
               }}
               transition={{ repeat: Infinity, duration: 5 }}
               className="w-32 h-32 bg-black dark:bg-white flex items-center justify-center rounded-[2.5rem] shadow-2xl relative z-10"
             >
               <span className="text-white dark:text-black font-serif text-7xl italic select-none" style={{ lineHeight: 0, marginTop: '-8px' }}>S</span>
             </motion.div>
             
             {/* Decorative glows */}
             <div className="absolute -inset-10 bg-zinc-200 dark:bg-zinc-800 rounded-[3.5rem] -z-10 blur-3xl opacity-20" />
          </div>

          <div className="overflow-hidden h-6">
            <motion.h1 
              initial={{ y: 30 }}
              animate={{ y: 0 }}
              transition={{ delay: 0.5, duration: 1, ease: [0.16, 1, 0.3, 1] }}
              className="text-[13px] font-black uppercase tracking-[0.6em] text-zinc-900 dark:text-white"
            >
              Smart Open AI
            </motion.h1>
          </div>
        </motion.div>

        {/* Loading Bar (iPhone style) */}
        <div className="w-48 h-[2px] bg-zinc-100 dark:bg-zinc-900 overflow-hidden rounded-full">
          <motion.div 
            initial={{ x: "-100%" }}
            animate={{ x: "0%" }}
            transition={{ duration: 1.8, ease: [0.65, 0, 0.35, 1], delay: 0.3 }}
            className="w-full h-full bg-black dark:bg-white"
          />
        </div>
      </div>

      <motion.footer 
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
        className="pb-16 w-full text-center"
      >
         <p className="text-[10px] uppercase tracking-[0.4em] text-zinc-300 dark:text-zinc-800 font-black">
           Proprietary Intelligence Node
         </p>
      </motion.footer>
    </motion.div>
  );
}
