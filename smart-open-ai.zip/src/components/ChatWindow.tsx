import { useState, useEffect, useRef } from "react";
import { db, auth } from "../lib/firebase";
import { collection, query, orderBy, onSnapshot, addDoc, serverTimestamp, doc, updateDoc, getDoc } from "firebase/firestore";
import { Send, Sparkles, Image as ImageIcon, Loader2, Download } from "lucide-react";
import { chatStream, generateImageFromPrompt } from "../services/gemini";
import Markdown from "react-markdown";
import { cn, resizeImage } from "../lib/utils";
import { motion, AnimatePresence } from "motion/react";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  type?: "text" | "image";
  imageUrl?: string;
}

interface ChatWindowProps {
  chatId: string | null;
  onNewChat: (id: string) => void;
}

export function ChatWindow({ chatId, onNewChat }: ChatWindowProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const user = auth.currentUser;

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.style.height = "auto";
      inputRef.current.style.height = `${inputRef.current.scrollHeight}px`;
    }
  }, [input]);

  useEffect(() => {
    if (chatId) {
      inputRef.current?.focus();
    }
  }, [chatId]);

  useEffect(() => {
    if (!user || !chatId) {
      setMessages([]);
      return;
    }

    const q = query(
      collection(db, "users", user.uid, "chats", chatId, "messages"),
      orderBy("createdAt", "asc")
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      setMessages(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })) as Message[]);
    });

    return () => unsubscribe();
  }, [user, chatId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isGenerating || !user) return;

    const currentInput = input;
    setInput("");
    setIsGenerating(true);

    setError(null);
    try {
      let activeChatId = chatId;
      
      // Create new chat if none selected
      if (!activeChatId) {
        const chatRef = await addDoc(collection(db, "users", user.uid, "chats"), {
          title: currentInput.slice(0, 30) + (currentInput.length > 30 ? "..." : ""),
          createdAt: serverTimestamp(),
          userId: user.uid,
        });
        activeChatId = chatRef.id;
        onNewChat(activeChatId);
      }

      // Add user message
      await addDoc(collection(db, "users", user.uid, "chats", activeChatId, "messages"), {
        role: "user",
        content: currentInput,
        createdAt: serverTimestamp(),
      });

      // Broad heuristic for image generation (English and Dutch since the user uses both)
      const imageKeywords = ["generate image", "make an image", "create an image", "maak een plaatje", "maak een foto", "genereer afbeelding"];
      const isImageRequest = imageKeywords.some(keyword => currentInput.toLowerCase().includes(keyword));

      if (isImageRequest) {
        const rawImageUrl = await generateImageFromPrompt(currentInput);
        if (rawImageUrl) {
          // Resize and compress to stay under 1MB
          const imageUrl = await resizeImage(rawImageUrl);
          
          await addDoc(collection(db, "users", user.uid, "chats", activeChatId, "messages"), {
            role: "assistant",
            content: "Here is the image I generated for you:",
            type: "image",
            imageUrl,
            createdAt: serverTimestamp(),
          });
        } else {
          throw new Error("I could not generate that image. The neural synthesis returned an empty result.");
        }
      } else {
        // Chat response
        const messagesForAI = [...messages, { role: "user", content: currentInput }].map(m => ({
          role: m.role,
          content: m.content
        })) as any[];

        const stream = await chatStream(messagesForAI);
        let assistantContent = "";
        
        // Optimistically add an empty assistant message to update
        const assistantMsgRef = await addDoc(collection(db, "users", user.uid, "chats", activeChatId, "messages"), {
          role: "assistant",
          content: "",
          createdAt: serverTimestamp(),
        });

        for await (const chunk of stream) {
          if (chunk.text) {
            assistantContent += chunk.text;
            await updateDoc(doc(db, "users", user.uid, "chats", activeChatId!, "messages", assistantMsgRef.id), {
              content: assistantContent
            });
          }
        }
      }
    } catch (error: any) {
      console.error("Chat error:", error);
      setError(error.message || "An error occurred with the AI service. Please check your configuration.");
    } finally {
      setIsGenerating(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSend();
  };

  if (!chatId && messages.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 md:p-12 bg-zinc-50 dark:bg-zinc-950 relative overflow-hidden transition-colors duration-300">
         {/* Background Decor */}
         <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-zinc-100 dark:bg-zinc-900/50 rounded-full blur-3xl opacity-50 -translate-y-1/2 translate-x-1/2 pointer-events-none" />
         
         <motion.div 
           initial={{ opacity: 0, y: 30 }}
           animate={{ opacity: 1, y: 0 }}
           className="text-center space-y-16 max-w-2xl z-10 w-full"
         >
            <div className="space-y-6">
              <div className="mx-auto w-20 h-20 bg-black dark:bg-white flex items-center justify-center rounded-[1.5rem] shadow-2xl mb-8">
                 <span className="text-white dark:text-black font-serif text-5xl italic select-none">S</span>
              </div>
              <h2 className="font-serif text-6xl md:text-8xl italic text-zinc-900 dark:text-white tracking-tight leading-none text-balance">
                How can I help <br />
                <span className="text-zinc-300 dark:text-zinc-700">u today?</span>
              </h2>
            </div>
            
            <ChatInput 
              input={input}
              setInput={setInput}
              onSubmit={handleSubmit}
              isGenerating={isGenerating}
              inputRef={inputRef}
              error={error}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-3xl mx-auto text-left opacity-60 hover:opacity-100 transition-opacity">
              <div className="border-l border-zinc-200 dark:border-zinc-800 pl-6 space-y-3">
                <p className="text-[10px] uppercase font-black tracking-[0.3em] text-zinc-900 dark:text-white">Image Synthesis</p>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 font-serif italic">
                  Generate hyper-real visuals using our latest neural architecture.
                </p>
              </div>
              <div className="border-l border-zinc-200 dark:border-zinc-800 pl-6 space-y-3">
                <p className="text-[10px] uppercase font-black tracking-[0.3em] text-zinc-900 dark:text-white">Logic Engine</p>
                <p className="text-xs text-zinc-500 dark:text-zinc-400 font-serif italic">
                  Execute complex reasoning with beyond-V1 performance.
                </p>
              </div>
            </div>
         </motion.div>

         <footer className="absolute bottom-8 w-full text-center text-[9px] uppercase tracking-[0.4em] text-zinc-300 dark:text-zinc-800 font-black">
           Powered by Proprietary Beyond-V1 Architecture
         </footer>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col h-full bg-white dark:bg-zinc-950 relative font-sans transition-colors duration-300">
      <nav className="h-20 flex items-center justify-between px-10 iphone-blur sticky top-0 z-20 border-b border-zinc-100 dark:border-zinc-900 shadow-sm transition-all duration-500">
        <div className="flex gap-8">
          <span className="text-[9px] uppercase font-black tracking-widest text-zinc-900 dark:text-white">Beyond-V1</span>
          <span className="text-[9px] uppercase font-black tracking-widest text-zinc-200 dark:text-zinc-800">Processing...</span>
        </div>
        <div className="text-[10px] uppercase font-bold tracking-[0.2em] text-zinc-400 dark:text-zinc-600 italic font-serif">
          Journal No. {chatId?.slice(0, 12)}
        </div>
      </nav>

      <div className="flex-1 overflow-y-auto px-8 py-16 space-y-16 no-scrollbar">
        <div className="max-w-4xl mx-auto space-y-20">
          {messages.map((m) => (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              key={m.id}
              className={cn(
                "flex flex-col",
                m.role === "user" ? "items-end" : "items-start"
              )}
            >
              <div className={cn(
                "max-w-[90%] p-8 rounded-[2rem]",
                m.role === "user" 
                  ? "bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 text-zinc-900 dark:text-white shadow-sm" 
                  : "bg-white dark:bg-transparent text-zinc-800 dark:text-zinc-100"
              )}>
                {m.role === "user" ? (
                  <p className="font-serif italic text-xl leading-relaxed">{m.content}</p>
                ) : (
                  <div className="space-y-8">
                    {m.type === "image" && m.imageUrl ? (
                      <div className="space-y-8">
                        <div className="overflow-hidden rounded-[2.5rem] border border-zinc-100 dark:border-zinc-800 shadow-2xl">
                            <img 
                            src={m.imageUrl} 
                            alt="Generated" 
                            className="w-full h-auto grayscale-[20%] hover:grayscale-0 transition-all duration-700"
                            referrerPolicy="no-referrer"
                            />
                        </div>
                        <div className="flex items-center justify-between">
                          <p className="text-[10px] uppercase font-bold tracking-[0.3em] text-zinc-400 dark:text-zinc-600 border-l-2 border-zinc-900 dark:border-zinc-100 pl-6">
                             Syn-Output: {Math.random().toString(36).substring(7).toUpperCase()}
                          </p>
                          <button
                            onClick={() => {
                              const link = document.createElement("a");
                              link.href = m.imageUrl!;
                              link.download = `syn-output-${m.id}.jpg`;
                              document.body.appendChild(link);
                              link.click();
                              document.body.removeChild(link);
                            }}
                            className="flex items-center gap-2 text-[10px] uppercase font-bold tracking-[0.3em] text-zinc-400 dark:text-zinc-600 hover:text-black dark:hover:text-white transition-colors"
                          >
                            <Download className="w-3 h-3" />
                            Download
                          </button>
                        </div>
                      </div>
                    ) : (
                      <div className="prose prose-zinc dark:prose-invert prose-lg leading-relaxed font-sans">
                        <Markdown>{m.content}</Markdown>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>

      <div className="p-10 border-t border-zinc-100 dark:border-zinc-900 bg-white dark:bg-zinc-950 shadow-2xl">
        <div className="max-w-4xl mx-auto">
          <ChatInput 
            input={input} 
            setInput={setInput} 
            onSubmit={handleSubmit} 
            isGenerating={isGenerating} 
            inputRef={inputRef}
            error={error}
          />
        </div>
      </div>
    </div>
  );
}

function ChatInput({ input, setInput, onSubmit, isGenerating, inputRef, error }: any) {
  return (
    <div className="flex flex-col gap-3">
      {error && (
        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="mx-auto bg-red-50 dark:bg-red-900/20 border border-red-100 dark:border-red-900/30 text-red-600 dark:text-red-400 px-6 py-3 rounded-2xl text-[10px] font-bold uppercase tracking-widest flex items-center gap-3"
        >
          <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
          {error}
        </motion.div>
      )}
      <form onSubmit={onSubmit} className="relative group">
        <div className="bg-zinc-50 dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-800 flex items-center transition-all group-within:border-zinc-500 rounded-[2.5rem] px-6 shadow-sm group-within:shadow-xl">
          <button
            type="button"
            className="p-4 text-zinc-300 dark:text-zinc-700 hover:text-black dark:hover:text-white transition-colors"
          >
            <ImageIcon className="w-5 h-5 italic" />
          </button>
          <textarea
            ref={inputRef}
            rows={1}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                onSubmit(e);
              }
            }}
            placeholder="Enter prompt..."
            className="flex-1 bg-transparent border-none focus:ring-0 text-zinc-900 dark:text-white placeholder:text-zinc-300 dark:placeholder:text-zinc-700 font-sans text-sm px-4 py-6 max-h-[200px] resize-none outline-none rounded-2xl"
          />
        <button
          type="submit"
          disabled={!input.trim() || isGenerating}
          className="px-8 py-5 transition-all"
        >
          {isGenerating ? (
            <Loader2 className="w-5 h-5 animate-spin text-zinc-900 dark:text-white" />
          ) : (
            <div className={cn(
              "text-[10px] font-black uppercase tracking-[0.3em] border-b-2 transition-all",
              input.trim() ? "border-black dark:border-white text-black dark:text-white" : "border-zinc-200 dark:border-zinc-800 text-zinc-200 dark:text-zinc-800"
            )}>Send</div>
          )}
        </button>
        </div>
      </form>
    </div>
  );
}
