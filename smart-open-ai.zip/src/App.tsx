import { useEffect, useState } from "react";
import { auth, loginWithGoogle } from "./lib/firebase";
import { onAuthStateChanged, User } from "firebase/auth";
import { ChatWindow } from "./components/ChatWindow";
import { Sidebar } from "./components/Sidebar";
import { ProfileModal } from "./components/ProfileModal";
import { SplashScreen } from "./components/SplashScreen";
import { LogIn, Sparkles } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showSplash, setShowSplash] = useState(true);
  const [currentChatId, setCurrentChatId] = useState<string | null>(null);
  const [showProfile, setShowProfile] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    // Sync theme immediately on load
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
       setIsDarkMode(true);
       document.documentElement.classList.add('dark');
    }

    const unsubscribe = onAuthStateChanged(auth, (u) => {
      setUser(u);
      
      // Artificial delay for splash elegance
      setTimeout(() => {
        setIsLoading(false);
        // Fade out splash after content is ready
        setTimeout(() => setShowSplash(false), 600);
      }, 1800);
    });
    return () => unsubscribe();
  }, []);

  const toggleTheme = () => {
    const newValue = !isDarkMode;
    setIsDarkMode(newValue);
    if (newValue) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  };

  return (
    <div className="h-screen w-full bg-zinc-50 dark:bg-zinc-950 flex overflow-hidden font-sans transition-colors duration-300">
      <AnimatePresence>
        {showSplash && <SplashScreen />}
      </AnimatePresence>

      {!isLoading && !user ? (
        <div className="h-screen w-full flex flex-col items-center justify-center bg-zinc-50 dark:bg-zinc-950 px-8 text-center">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-12 max-w-md"
          >
            <div className="flex flex-col items-center gap-6">
              <div className="w-16 h-16 bg-black dark:bg-white flex items-center justify-center rounded-[1.25rem] shadow-xl">
                <span className="text-white dark:text-black font-serif text-4xl italic">S</span>
              </div>
              <div className="space-y-2">
                <h1 className="text-xs font-bold uppercase tracking-[0.3em] text-zinc-900 dark:text-white">Smart Open AI</h1>
                <p className="text-zinc-400 dark:text-zinc-500 font-serif italic text-lg">Beyond current intelligence</p>
              </div>
            </div>
            
            <button
              onClick={loginWithGoogle}
              className="w-full flex items-center justify-center gap-4 border-2 border-black dark:border-white bg-black dark:bg-white text-white dark:text-black px-8 py-5 text-xs font-bold uppercase tracking-widest hover:bg-zinc-800 dark:hover:bg-zinc-200 transition-all shadow-lg rounded-2xl"
            >
              <LogIn className="w-4 h-4" />
              Continue with Google
            </button>

            <footer className="pt-12 text-[10px] uppercase tracking-widest text-zinc-300 dark:text-zinc-700 font-medium font-sans">
              Proprietary Beyond-V1 Architecture
            </footer>
          </motion.div>
        </div>
      ) : !isLoading && user ? (
        <>
          <Sidebar 
            currentChatId={currentChatId} 
            onChatSelect={setCurrentChatId} 
            onOpenProfile={() => setShowProfile(true)}
            isDarkMode={isDarkMode}
            toggleTheme={toggleTheme}
          />
          
          <main className="flex-1 flex flex-col overflow-hidden relative">
            <ChatWindow 
              chatId={currentChatId} 
              onNewChat={(id) => setCurrentChatId(id)}
            />
          </main>

          <AnimatePresence>
            {showProfile && (
              <ProfileModal onClose={() => setShowProfile(false)} />
            )}
          </AnimatePresence>
        </>
      ) : null}
    </div>
  );
}

